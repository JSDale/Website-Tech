function toggleClass()
{
    let menu = document.querySelector(".Menu");
    menu.classList.toggle("toggleCls");
}